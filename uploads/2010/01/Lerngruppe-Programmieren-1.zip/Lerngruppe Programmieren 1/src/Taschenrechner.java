public class Taschenrechner 
{
	/**
	 * Berechnet die Fakultät von basis rekursiv
	 * 
	 * @param Basis
	 * @return Fakultät
	 */
	public static int fakultaet(int basis)
	{
		if (basis < 1) return 1;
		return basis * fakultaet(basis - 1);
	}
	
	/**
	 * Berechnet die Fakultät von basis iterativ
	 * 
	 * @param Basis
	 * @return Fakultät
	 */
	public static int fakultaetIterativ(int basis)
	{
		if (basis < 1) return 1;
		int ergebnis = 1;
		
		for (int n = basis; n > 0; n--) {
			ergebnis = ergebnis * n;
		}
		
		return ergebnis;
	}
	
}
