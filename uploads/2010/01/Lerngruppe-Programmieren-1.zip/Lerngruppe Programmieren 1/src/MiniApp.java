/**
 * Einstiegs-Klasse
 * 
 * Erzeugt ein Radio.
 */
public class MiniApp 
{
	private static Radio myRadio;
	
	/**
	 * Wird immer aufgerufen.
	 * Erzeugt das Radio
	 * 
	 * @param Übergeben Argumente
	 */
	public static void main(String[] args) 
	{
		// Fakultät berechnen
		System.out.println(Taschenrechner.fakultaet(3)); // Ausgabe muss 6 sein
		System.out.println(Taschenrechner.fakultaetIterativ(3)); // Ausgabe muss 6 sein
		
		// Ein Radio erzeugen, aber nirgends "ablegen"
		// new Radio();
		// Ein Radio erzeugen, und in der lokalen Variable myLocalRadio "ablegen"
		Radio myLocalRadio = new Radio();
		myLocalRadio.setVolume(800);
		System.out.println(myLocalRadio.getVolume()); // Ausgabe muss 100 sein
		myLocalRadio.setVolume(-78);
		System.out.println(myLocalRadio.getVolume()); // Ausgabe muss 0 sein
		myLocalRadio.setVolume(95);
		myLocalRadio.lauter();
		System.out.println(myLocalRadio.getVolume()); // Ausgabe muss 100 sein
		myLocalRadio.setVolume(5);
		myLocalRadio.leiser();
		System.out.println(myLocalRadio.getVolume()); // Ausgabe muss 0 sein
		// Ein Radio erzeugen, und in der Klassen-Variable myLocalRadio "ablegen"
		// myRadio = new Radio();
		// Ein Radio mit Startwerten
		double freqHr3 = 89.3;
		Radio myPartyRadio = new Radio(freqHr3, 800, true);
		System.out.println(myPartyRadio.getFreq()); // Ausgabe muss 89.3 sein
		System.out.println(myPartyRadio.getVolume()); // Ausgabe muss 100 sein
		
		// Beispiel für hierarchische Konstruktoren
		// Überladen von Konstruktoren
		new Radio();
		new Radio(freqHr3);
		new Radio(freqHr3, 90);
		new Radio(freqHr3, 90, true);
		
		// Überladen von Methoden
		Radio lautRadio = new Radio();
		lautRadio.lauter(); // erhöht um 10 = lauter(10)
		lautRadio.lauter(30); // erhöht um 30
		System.out.println(lautRadio.getVolume()); // Ausgabe muss 90 sein
		lautRadio.printSenderList();
	}
}
