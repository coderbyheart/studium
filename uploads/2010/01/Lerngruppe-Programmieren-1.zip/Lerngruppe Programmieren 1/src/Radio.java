/**
 * Repräsentiert ein Radio
 */
public class Radio
{
	private double freq;
	private int volume;
	private boolean an;
	private Sender[] sender;
	
	/**
	 * "Leerer" Konstruktor
	 */
	public Radio() {
		this(100);
	}
	
	/**
	 * Ein Konstruktor der Frequenz
	 * 
	 * @param Frequenz
	 */
	public Radio(double freq)
	{
		this(freq, 50);
	}
	
	/**
	 * Ein Konstruktor der Frequenz und Lautstärke
	 * 
	 * @param Frequenz
	 * @param Lautstärke
	 */
	public Radio(double freq, int volume)
	{
		this(freq, volume, true);
	}
	
	/**
	 * Ein Konstruktor der Frequenz, Lautstärke und An setzt
	 * 
	 * @param Frequenz
	 * @param Lautstärke
	 * @param An/Aus
	 */
	public Radio(double freq, int volume, boolean an)
	{
		this.freq = freq;
		setVolume(volume);
		this.an = an;
		this.sender = new Sender[] {
			new Sender("HR3", 89.3),
			new Sender("YOUFM", 101.1),
			new Sender("HR4", 102.2),
			new Sender("HR1", 103.3),
			new Sender("HR INFO", 104.4),
			new Sender("HR2", 105.5)
		};
	}
	
	/**
	 * Gibt die Frequenz zurück
	 * 
	 * @return Frequenz
	 */
	public double getFreq()
	{
		return freq;
	}
	
	/**
	 * Setzt die Frequenz
	 * 
	 * @param Frequenz
	 */
	public void setFreq(double freq)
	{
		this.freq = freq;
	}
	
	public void switchOnOff()
	{
		an = !an;
	}
	
	/**
	 * Erhöht die Lautstärke immer um 10
	 * 
	 * Aber nicht höher als 100
	 */
	public void lauter()
	{
		lauter(10);
	}
	
	/**
	 * Erhöht die Lautstärke um ein beliebigen increment
	 * 
	 * Aber nicht höher als 100
	 */
	public void lauter(int increment)
	{
		setVolume(getVolume() + increment);
	}
	
	/**
	 * Verringert die Lautstärke immer um 10
	 * 
	 * Aber nicht niedriger als 0
	 */
	public void leiser()
	{
		setVolume(getVolume() - 10);
	}
	
	/**
	 * Setzt die Lautsärke
	 * 
	 * @param Lautstärke
	 */
	public void setVolume(int v)
	{
		if (v >= 0 && v <= 100) {
			this.volume = v;
		} else {
			if (v < 0) this.volume = 0;
			if (v > 100) this.volume = 100;
		}
	}
	
	public int getVolume()
	{
		return volume;
	}
	
	public void printSenderList()
	{
		for(int i = 0; i < this.sender.length; i++) {
			System.out.println(this.sender[i]);
		}
	}
}