public class Sender 
{
	private String name;
	private double freq;
	
	public Sender(String name, double freq)
	{
		this.name = name;
		this.freq = freq;
	}

	public String getName() {
		return name;
	}

	public double getFreq() {
		return freq;
	}

	public String toString()
	{
		return this.getFreq() + ": " + this.getName();
	}
}
